<?xml version="1.0" encoding="UTF-8"?>
<tileset name="spritesheet(2)" tilewidth="32" tileheight="32" tilecount="13" columns="13">
 <image source="tiles.png" width="416" height="32"/>
</tileset>
