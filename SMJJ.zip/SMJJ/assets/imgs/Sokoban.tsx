<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Sokoban" tilewidth="32" tileheight="32" tilecount="416" columns="26">
 <image source="sokoban.png" width="832" height="512"/>
 <tile id="332">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="333">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="334">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="335">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="336">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="337">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="358">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="359">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="360">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="361">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="362">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="363">
  <properties>
   <property name="isMovable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="386">
  <properties>
   <property name="isMovable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="387">
  <properties>
   <property name="isMovable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="412">
  <properties>
   <property name="isMovable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="413">
  <properties>
   <property name="isMovable" type="bool" value="false"/>
  </properties>
 </tile>
</tileset>
